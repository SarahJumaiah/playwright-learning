import { test } from '@playwright/test';
import { POManager } from '../../ui/pages/poManager';
import tsData from '../../../testData/testUsers';
import mockedResponse from '../../../mocks/responseInterception.json';
//======================Variables======================
let poManager: POManager;
//======================Hooks==========================
test.beforeEach('This actions run before every test', async ({ page }, testInfo) => {
    poManager = new POManager(page);
    await poManager.getLoginPage().open();
    console.log(`test starts for: ${testInfo.title}`);
});
//======================Tests==========================
test.describe('Network interception', () => {
    test('intercept browser api response', async ({ page }) => {
        await poManager.getLoginPage().login(tsData.username, tsData.password);
        await page.getByText('PIM').click();
        const employeeResponse = await page.waitForResponse(response =>
            response.url().startsWith(
                'https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/pim/employees?limit=50&offset=0'
            )
        );
        const employeeResponseBody = await employeeResponse.json();
        console.log(employeeResponseBody);
        const empNumber = employeeResponseBody.data[0].empNumber;
        console.log(empNumber);
        const requestBody = {
            "ids": [empNumber]
        };
        const deletedEmpResponse = await page.request.delete(
            'https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/pim/employees',
            {
                data: requestBody
            }
        );
        const deletedEmployeeResponseBody = await deletedEmpResponse.json();
        console.log(deletedEmployeeResponseBody);
    });

    test('Mocking1: mock api response', async ({ page }) => {
        await page.route('https://api.randomuser.me/?nat=us', async route => {
            await route.fulfill({
                body: JSON.stringify(mockedResponse)
            });
        });

        await page.goto('https://demo.automationtesting.in/DynamicData.html');
        await page.locator('#save').click();
        await expect(page.locator('#loading'))
            .toContainText('First Name : PlaywrightLast Name : User');
    });
});